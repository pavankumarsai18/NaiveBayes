Name: Venkata Vadrevu
FSU id: vv18d
CIS4930

How to run the program?
------------------------
Use the command below to run the program. 

"python3 NaiveBayes.py trainfile testfile"


What does this program do?
--------------------------
The program uses NaiveBayes method to predict the class label. It first trains the model using the 
trinfile and then it predicts the classLabel for each instance in the trainfile and testfile.


What is the output?
-------------------
The 8 integers are (first line) true positive in training, false negative in training,
false positive in training, and true negative in training, and (second line) true positive
in test, false negative in test, false positive in test, and true negative in test.